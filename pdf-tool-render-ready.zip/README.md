# PDF Tool
Projeto Flask pronto para Render.

## Rodar localmente
```bash
pip install -r requirements.txt
python -m src.app
```

## Deploy no Render
- Build command: `pip install -r requirements.txt`
- Start command: conforme Procfile
