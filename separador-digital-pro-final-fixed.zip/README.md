
# Separador Digital Pro

Um site simples para dividir PDFs em páginas individuais ou intervalos personalizados.

## Funcionalidades
- Login com senha fixa (`29031984bB@G`)
- Upload de PDF
- Divisão por páginas individuais (gera ZIP)
- Divisão por intervalo
- Modo claro/escuro com botão
- Feedback visual de sucesso/erro
- Rodapé personalizado
- Hover nos botões, links e rodapé

## Deploy no Render
1. Crie um repositório no GitHub e faça push dos arquivos.
2. No Render, crie um novo Web Service a partir do repositório.
3. Configure o Start Command: `python app.py`
4. Deploy!

